<?php 

// All Departments
function getAllDepartments($conn){
   $sql = "SELECT * FROM departments";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if ($stmt->rowCount() >= 1) {
     $departments = $stmt->fetchAll();
     return $departments;
   }else {
   	return 0;
   }
}



// Get Student By Id 
function getDepartmenttById($id, $conn){
   $sql = "SELECT * FROM departments
           WHERE dep_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$id]);

   if ($stmt->rowCount() == 1) {
     $department = $stmt->fetch();
     return $department;
   }else {
    return 0;
   }
}


// Check if the username Unique
function unameIsUnique($dep_name, $conn, $dep_id=0){
   $sql = "SELECT dep_name, dep_id FROM departments
           WHERE dep_name=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$dep_name]);
   
   if ($dep_id == 0) {
     if ($stmt->rowCount() >= 1) {
       return 0;
     }else {
      return 1;
     }
   }else {
    if ($stmt->rowCount() >= 1) {
       $department = $stmt->fetch();
       if ($department['dep_id'] == $dep_id) {
         return 1;
       }else {
        return 0;
      }
     }else {
      return 1;
     }
   }
   
}


