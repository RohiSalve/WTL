<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/remixicon@3.4.0/fonts/remixicon.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <title>CODE AASHU | Health Care</title>
  <style>
    /* Additional CSS for error messages */
    .error-message {
      color: red;
      margin-top: 5px;
    }
  </style>
</head>
<body>
  <header>
    <nav class="section__container nav__container">
      <div   class="nav__logo">Health<span>Care</span></div>
      <ul class="nav__links">
        <li class="link"><a href="index.php">Home</a></li>
        <li class="link"><a href="admin.php">Admin </a></li>
      </ul>
      <button class="btn">Contact Us</button>
    </nav>
    <div class="section__container header__container">
      <div class="header__content">
        <h1>Admin Panel</h1>
        <p>Here is our admin panel. Admin please login to see the Appointment details</p>
      </div>
      <div class="header__form">
        <form id="loginForm" action="panel.php" method="post" onsubmit="return validateForm()">
          <h4>Admin Login</h4>
          <input type="text" name="username" id="username" placeholder="Username" />
          <div id="usernameError" class="error-message"></div>
          <input type="password" name="password" id="password" placeholder="Password" />
          <div id="passwordError" class="error-message"></div>
          <button type="submit" class="btn form__btn">Sign In</button>
        </form>
      </div>
    </div>
  </header>
  <footer class="footer">
    <div class="section__container footer__container">
      <div class="footer__col">
        <h3>Health<span>Care</span></h3>
        <p>We are honored to be a part of your healthcare journey and committed
          to delivering compassionate, personalized, and top-notch care every
          step of the way.</p>
        <p>Trust us with your health, and let us work together to achieve the
          best possible outcomes for you and your loved ones.</p>
      </div>
      <div class="footer__col">
        <h4>About Us</h4>
        <p>Home</p>
        <p>About Us</p>
        <p>Work With Us</p>
        <p>Our Blog</p>
        <p>Terms & Conditions</p>
      </div>
      <div class="footer__col">
        <h4>Services</h4>
        <p>Search Terms</p>
        <p>Advance Search</p>
        <p>Privacy Policy</p>
        <p>Suppliers</p>
        <p>Our Stores</p>
      </div>
      <div class="footer__col">
        <h4>Contact Us</h4>
        <p><i class="ri-map-pin-2-fill"></i> Near Bhajimandi, Kopargoan</p>
        <p><i class="ri-mail-fill"></i> support@care.com</p>
        <p><i class="ri-phone-fill"></i> (+91) 93097 76436</p>
      </div>
    </div>
    <div class="footer__bar">
      <div class="footer__bar__content">
        <p>Copyright © 2024 SCOEIT_G3. All rights reserved.</p>
        <div class="footer__socials">
          <span><i class="ri-instagram-line"></i></span>
          <span><i class="ri-facebook-fill"></i></span>
          <span><i class="ri-heart-fill"></i></span>
          <span><i class="ri-twitter-fill"></i></span>
        </div>
      </div>
    </div>
  </footer>
  <script>
    // Function to validate form fields
    function validateForm() {
      var username = document.getElementById("username").value;
      var password = document.getElementById("password").value;
      var usernameError = document.getElementById("usernameError");
      var passwordError = document.getElementById("passwordError");
      var isValid = true;

      // Reset previous error messages
      usernameError.innerHTML = "";
      passwordError.innerHTML = "";

      // Check if username is empty
      if (username.trim() === "") {
        usernameError.innerHTML = "Username is required";
        isValid = false;
      }

      // Check if password is empty
      if (password.trim() === "") {
        passwordError.innerHTML = "Password is required";
        isValid = false;
      }

      // Check if username and password match
      if (username !== "Rohit" || password !== "Rohit@123") {
        usernameError.innerHTML = "Invalid username or password";
        passwordError.innerHTML = "Invalid username or password";
        isValid = false;
      }

      // If everything is valid, redirect to panel.php
      if (isValid) {
        window.location.href = "panel.php";
      }

      return isValid;
    }
  </script>
</body>
</html>
