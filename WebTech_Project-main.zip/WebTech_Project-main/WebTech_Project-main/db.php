<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $date = $_POST['Date']; // corrected to match the input name
    $time = $_POST['time'];

    $sName = "localhost";
    $uName = "root";
    $pass  = "";
    $db_name = "admin";

    try {
        $conn = new PDO("mysql:host=$sName;dbname=$db_name", $uName, $pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // SQL query to create appointments table if it doesn't exist
        $sql_create_table = "CREATE TABLE IF NOT EXISTS appointments (
                                id INT AUTO_INCREMENT PRIMARY KEY,
                                first_name VARCHAR(50) NOT NULL,
                                last_name VARCHAR(50) NOT NULL,
                                address VARCHAR(255) NOT NULL,
                                phone VARCHAR(15) NOT NULL,
                                date DATE NOT NULL,
                                time TIME NOT NULL
                            )";
        $conn->exec($sql_create_table);

        // SQL query to insert data into the appointments table
        $sql_insert = "INSERT INTO appointments (first_name, last_name, address, phone, date, time)
                       VALUES ('$first_name', '$last_name', '$address', '$phone', '$date', '$time')";
        $conn->exec($sql_insert);

        echo "Appointment booked successfully!";
    } catch(PDOException $e) {
        echo "Connection failed: ". $e->getMessage();
    }

    // Close database connection
    $conn = null;
}
?>
